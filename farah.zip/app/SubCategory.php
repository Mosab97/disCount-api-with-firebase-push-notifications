<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubCategory extends Model
{
    protected $fillable = [
        'user_id', 'name', 'address','mobile', 'is_active', 'description','workdays', 'open_time', 'close_time','url_whatsApp', 'url_facebook',
        'cityName', 'average_price', 'evaluation', 'lattude', 'longtude', 'image', 'category_id', 'url_youtube',
        'Offer_value', 'is_offer',
    ];


    public function users(){

        return $this->belongsTo(User::class);
    }

    public function categories(){

        return $this->belongsTo(Category::class);
    }

    public function cities(){

        return $this->hasMany(City::class);
    }

    public function uploades(){

        return $this->hasMany(Upload::class);
    }
}
