<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function index(Request $request)
    {
        $clients = User::when($request->search, function ($q) use ($request) {
            return $q->where('name', 'like', '%' . $request->search . '%')
                ->orWhere('email', 'like', '%' . $request->search . '%');
        })->latest()->paginate(5);
        return view('dashboard.clients.index', compact('clients'));
    }

    public function destroy(User $user)
    {

        $user->delete();
        session()->flash('success', __('تم الحذف بنجاح'));
        return redirect()->route('dashboard.clients.index');
    }


    public function indexRequest()
    {
        $clients_request = User::where('is_active','0')->latest()->paginate(5);;
        return view('dashboard.clients.request', compact('clients_request'));
    }

    public function request_accept($id){
        User::where('id',  $id)->update(['is_active' => 1]);
        session()->flash('success', __('تم تفعيل الحساب بنجاح'));
        return redirect()->route('dashboard.clients.index');


    }
}
