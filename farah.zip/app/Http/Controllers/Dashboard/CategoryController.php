<?php

namespace App\Http\Controllers\Dashboard;

use App\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{

    public function index()
    {
        $categories = Category::all();
        return view('dashboard.categories.index', compact('categories'));
    }


    public function create()
    {
        return view('dashboard.categories.create');
    }


    public function store(Request $request)
    {
        $rules = [

            'icon' => 'sometimes|nullable|' . v_images(),
            'keywords' => 'sometimes|nullable|string',
            'parent_id' => 'sometimes|nullable|numeric|exists:categories,id',
            'special' => 'required|in:yes,no',
            'main' => 'required|in:yes,no',
            'slider' => 'required|in:yes,no',
            'in_header' => 'required|in:yes,no',
        ];

        foreach (config('translatable.locales') as $locale) {
            $rules += [$locale . '.category_name' => ['required', 'string']];
            $rules += [$locale . '.category_description' => 'required'];
        } // end of foreach

        $data = $request->validate($rules, [], [
            'icon' => trans('site.category_icon'),
            'keywords' => trans('site.address'),
            'parent_id' => trans('site.parent_id'),
            'special' => trans('site.special'),
            'main' => trans('site.main'),
            'slider' => trans('site.slider'),
            'in_header' => trans('site.in_header'),
        ]);

        if ($request->hasFile('icon'))
            $data['icon'] = up()->upload([
                'file' => 'icon',
                'upload_type' => 'single',
                'path' => 'category_images',
                'delete_file' => ''
            ]);

        Category::create($data);
        session()->flash('success', __('site.added_successfully'));

        return redirect()->route('dashboard.categories.index');
    }




    public function edit(Category $category)
    {
        return view('dashboard.categories.edit', compact('category'));
    }


    public function update(Request $request, Category $category)
    {
        $rules = [

            'icon' => 'sometimes|nullable|' . v_images(),
            'keywords' => 'sometimes|nullable|string',
            'parent_id' => 'sometimes|nullable|numeric|exists:categories,id',
            'special' => 'required|in:yes,no',
            'main' => 'required|in:yes,no',
            'slider' => 'required|in:yes,no',
            'in_header' => 'required|in:yes,no'

        ];

        foreach (config('translatable.locales') as $locale) {
            $rules += [$locale . '.category_name' => ['required', 'string']];
            $rules += [$locale . '.category_description' => 'required'];
        } // end of foreach

        $data = $request->validate($rules, [], [
            'icon' => trans('site.category_icon'),
            'keywords' => trans('site.address'),
            'parent_id' => trans('site.parent_id'),
            'special' => trans('site.special'),
            'main' => trans('site.special'),
            'slider' => trans('site.slider'),
            'in_header' => trans('site.in_header'),
        ]);

        if ($request->hasFile('icon'))
            $data['icon'] = up()->upload([
                'file' => 'icon',
                'upload_type' => 'single',
                'path' => 'category_images',
                'delete_file' => $category->icon
            ]);

        $category->update($data);
        session()->flash('success', __('site.updated_successfully'));

        return redirect()->route('dashboard.categories.index');
    }


    public function destroy(Category $category)
    {
        if ($category->icon != 'default.png' && \Storage::disk('public_uploads')->has('category_images/' . $category->icon))
            \Storage::disk('public_uploads')->delete('category_images/' . $category->icon);

        self::delete_childs_icons($category);

        $category->delete();
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.categories.index');
    }

    public static function delete_childs_icons(Category $category)
    {
        $cat_childs = Category::where('parent_id', $category->id)->get();

        foreach ($cat_childs as $cat_child) {
            self::delete_childs_icons($cat_child);

            if ($cat_child->icon != 'default.png' && \Storage::disk('public_uploads')->has('category_images/' . $cat_child->icon))
                \Storage::disk('public_uploads')->delete('category_images/' . $cat_child->icon);

        }
    }
}
