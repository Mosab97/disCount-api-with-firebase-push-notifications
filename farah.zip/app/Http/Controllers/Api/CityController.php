<?php

namespace App\Http\Controllers\Api;

use App\City;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function index(){
        $data = City::get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function add(Request $request){
        $cities = new City();
        $cities->name = $request->input('name');
        $cities->save();
        return response()->json(['status' => TRUE ,'messag' => 'OK' , 'data' => $cities]);

    }
}
