<?php

namespace App\Http\Controllers\Api;

use App\Category;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index(){
        $data = Category::get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function add(Request $request){
        $categories = new Category();
        $categories->name = $request->input('name');
        $categories->image = $request->input('image');
        $categories->save();
        return response()->json(['status' => TRUE ,'messag' => 'OK' , 'data' => $categories]);

    }
}
