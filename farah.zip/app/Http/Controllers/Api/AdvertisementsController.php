<?php

namespace App\Http\Controllers\Api;

use App\Advertisement;
use App\Http\Controllers\Controller;
use App\SubCategory;
use Illuminate\Http\Request;

class AdvertisementsController extends Controller
{
    public function index(){
         $data = Advertisement::get();
         return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function add(Request $request){
        $advertisements = new Advertisement();
        $advertisements->image = $request->input('image');
        $advertisements->text = $request->input('text');
        $advertisements->subCategory_id = $request->input('subCategory_id');
        $advertisements->save();
        return response()->json(['status' => TRUE ,'messag' => 'OK' , 'data' => $advertisements]);

    }


    public function getMarketFromAdvertisement($subCategory_id)
    {
        $data = SubCategory::where('id',$subCategory_id)->get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }


}
