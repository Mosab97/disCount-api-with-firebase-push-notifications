<?php

namespace App\Http\Controllers\Api;

use App\Category;
use App\City;
use App\Http\Controllers\Controller;
use App\SubCategory;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SubCategoryController extends Controller
{
    public function index(){
        $data = SubCategory::get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function getOfferMarket(){
        $data = SubCategory::select('name','address','Offer_value','evaluation','average_price')->where('is_offer', 1)->get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function add(Request $request ){
        $user =  Auth::user();
        $sub_categories = $user->sub_categories()->create($request->all());
        $sub_categories->save();
        return response()->json(['status' => TRUE ,'messag' => 'OK' , 'data' => $sub_categories]);

    }

    public function getmarket($category){
        $data = SubCategory::where('category_id',$category)->get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function edit(Request $request,  $id){
        $data = SubCategory::find($id);

        if ($request->input('name')) {
            $data->name = $request->input('name');
        }

        if ($request->input('address')) {
            $data->address = $request->input('address');
        }

        if ($request->input('mobile')) {
            $data->mobile = $request->input('mobile');
        }
        $data->save();
        return response()->json(['status' => True,  'message' => 'OK']);
    }

    public function getSearchResultsMarket(Request $request){
        $data = $request->get('data');
        $market = SubCategory::where('name', 'like', "%{$data}%")->get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $market]);

    }

    public function getSearchResultsCity(Request $request){
        $data = $request->get('data');
        $market = SubCategory::where('cityName', 'like', "%{$data}%")->get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $market]);

    }
}
