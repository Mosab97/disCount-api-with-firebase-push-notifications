<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\SubCategory;
use App\Upload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UploadimageController extends Controller
{
    public function index(){
        $data = Upload::get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }

    public function add(Request $request  ){
        $uploads = new Upload();
        $uploads->subCategory_id = $request->input('subCategory_id');
        $uploads->image = $request->input('image');
        $uploads->save();
        return response()->json(['status' => TRUE ,'messag' => 'OK' , 'data' => $uploads]);

    }

    public function getImageMarket($sub_category){
        $data = Upload::where('subCategory_id',$sub_category)->get();
        return response()->json(['status' => True,  'message' => 'OK', 'data' => $data]);
    }
}
