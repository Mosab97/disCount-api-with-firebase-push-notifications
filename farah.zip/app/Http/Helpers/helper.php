<?php
/**
 * Created by PhpStorm.
 * User: Samir
 * Date: 07/02/2019
 * Time: 11:22
 */



if (!function_exists('durl')) {

    function durl($url = null)
    {
        return url('dashboard/' . $url);
    }

}

if (!function_exists('admin')) {
    function admin() {
        return auth()->guard('admin');
    }
}

if (! function_exists('session')) {
    /**
     * Get / set the specified session value.
     *
     * If an array is passed as the key, we will assume you want to set an array of values.
     *
     * @param  array|string  $key
     * @param  mixed  $default
     * @return mixed|\Illuminate\Session\Store|\Illuminate\Session\SessionManager
     */
    function session($key = null, $default = null)
    {
        if (is_null($key)) {
            return app('session');
        }

        if (is_array($key)) {
            return app('session')->put($key);
        }

        return app('session')->get($key, $default);
    }
}

if (! function_exists('assett')) {
    /**
     * Generate an asset path for the application.
     *
     * @param  string  $path
     * @param  bool    $secure
     * @return string
     */
    function assett($path, $secure = null)
    {
        return app('url')->asset($path, $secure);
    }
}

if (!function_exists('load_cat')) {
    function load_cat($select = null, $cat_hide = null)
    {
        $categories = App\Category::selectRaw('id as id')
            ->selectRaw('parent_id as parent')
            ->get(['id', 'parent']);

        $cat_arr = [];

        foreach ($categories as $category) {
            $list_arr = [];
            $list_arr['icon'] = '';
            $list_arr['li_attr'] = '';
            $list_arr['a_attr'] = '';
            $list_arr['children'] = [];
            if (!is_null($select) && $select == $category->id) {
                $list_arr['state'] = [
                    'opened' => true,
                    'selected' => true,
                    'disabled' => false,
                ];
            }

            if (!is_null($cat_hide) && $cat_hide == $category->id) {
                $list_arr['state'] = [
                    'opened' => false,
                    'selected' => false,
                    'disabled' => true,
                    'hidden' => true,
                ];
            }

            $list_arr['id'] = $category->id;
            $list_arr['text'] = $category->translate(LaravelLocalization::getCurrentLocale())->category_name;
            $list_arr['parent'] = is_null($category->parent) ? '#' : $category->parent;

            array_push($cat_arr, $list_arr);

        }
        return json_encode($cat_arr, JSON_UNESCAPED_UNICODE);
    }
}

