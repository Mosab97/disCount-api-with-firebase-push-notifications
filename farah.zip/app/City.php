<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    public function sub_categories(){

        return $this->belongsTo(SubCategory::Class);
    }
}
