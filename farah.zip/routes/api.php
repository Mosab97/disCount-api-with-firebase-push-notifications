<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

    Route::post('/register', 'Api\AuthController@register');
    Route::post('/login', 'Api\AuthController@login');
    Route::get('/get_user', 'Api\AuthController@getuser');

    //advertisement
    Route::get('/get_advertisement', 'Api\AdvertisementsController@index');
    Route::post('/add_advertisement', 'Api\AdvertisementsController@add');
    Route::get('/get_marketAdvertisement/subCategory_id/{id}', 'Api\AdvertisementsController@getMarketFromAdvertisement');


    //cities
    Route::get('/get_cities', 'Api\CityController@index');
    Route::post('/add_cities', 'Api\CityController@add');

    //categories
    Route::get('/get_categories', 'Api\CategoryController@index');
    Route::post('/add_categories', 'Api\CategoryController@add');

    //sub_categories
    Route::get('/get_market/category_id/{id}', 'Api\SubCategoryController@getmarket');
    Route::get('/getOfferMarket', 'Api\SubCategoryController@getOfferMarket');
    Route::PUT('edit/subCategory_id/{id}','Api\SubCategoryController@edit');
    Route::get('/search_market', 'Api\SubCategoryController@getSearchResultsMarket');
    Route::get('/search_city', 'Api\SubCategoryController@getSearchResultsCity');

    //uploads
    Route::get('/get_ImageMarket/subCategory_id/{id}', 'Api\UploadimageController@getImageMarket');



Route::group(['middleware' => ['auth:api']], function(){
    //auth
    Route::post('/logout','Api\AuthController@logout');

    //sub_categories
    Route::get('/get_subCategories', 'Api\SubCategoryController@index');
    Route::post('/add_subCategories', 'Api\SubCategoryController@add');

    //uploads
    Route::get('/get_image', 'Api\UploadimageController@index');
    Route::post('/add_ImageMarket', 'Api\UploadimageController@add');

});

