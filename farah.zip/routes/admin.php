<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('dashboard')->name('dashboard.')->group(function () {

    Config::set('auth.defines', 'admin');
    Route::get('login', 'Dashboard\AdminAuthController@getLoginPage')->name('login');
    Route::post('login', 'Dashboard\AdminAuthController@login')->name('doLogin');
    Route::get('forgot/password', 'Dashboard\AdminAuthController@forgotPassword')->name('forgot');
    Route::post('forgot/password', 'Dashboard\AdminAuthController@submitForgotPassword')->name('submitForgot');
    Route::get('reset/password/{token}', 'Dashboard\AdminAuthController@resetPassword')->name('resetPassword');
    Route::post('reset/password/{token}', 'Dashboard\AdminAuthController@submitResetPassword')->name('submitResetPassword');

    Route::group(['middleware' => 'admin:admin'], function () {

        Route::any('logout', 'Dashboard\AdminAuthController@logout')->name('logout');
        Route::get('/index', 'Dashboard\DashboardController@index')->name('index');


        Route::get('clients/index', 'Dashboard\ClientController@index')->name('clients.index');
        Route::get('clients/request', 'Dashboard\ClientController@indexRequest')->name('clients.indexRequest');
        Route::get('request_accept/{id}', 'Dashboard\ClientController@request_accept')->name('clients.request_accept');
        Route::delete('clients/destroy/{user}', 'Dashboard\ClientController@destroy')->name('clients.destroy');

        Route::resource('categories', 'Dashboard\CategoryController');



    });
  });
