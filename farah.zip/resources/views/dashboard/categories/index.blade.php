@extends('layouts.dashboard.app')

@section('title', __('الأقسام'))

@section('css')
    <link rel="stylesheet" href="{{ asset('dashboard/assets/plugins/jstree/themes/default/style.css') }}">
@endsection

@section('breadcrumb')
    @include('layouts.dashboard._breadcrumb', [
        'title'=> trans('الأقسام'),
        'breadcrumb'=>[trans('الرئيسية') => route('dashboard.index'), trans('الأقسام') => '']
    ])
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">@lang('الأقسام')
                        <small>( {{ App\Category::count() }} )</small>
                    </h3>

                    @if ($categories->count() > 0)

                        <div class="mt-4" id="jstree"></div>

                        <input type="hidden" name="id" class="cat_id"/>

                        <div class="mt-3"></div>
                        <a href="" class="btn btn-outline-info edit_cat show_btn" hidden><i class="fa fa-edit"></i></a>

                        <form action="" class="form-del"
                              method="post" style="display: inline-block">
                            {{ csrf_field() }}
                            {{ method_field('delete') }}
                            <button type="submit" class="btn btn-outline-danger show_btn delete_cat" hidden><i
                                        class="fa fa-trash"></i></button>
                        </form><!-- end of form -->
                    @else

                        <h2 class="mt-4">@lang('site.no_data_found')</h2>

                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection

@section('js')
    <script src="{{ asset('dashboard/assets/plugins/jstree/jstree.js') }}"></script>
    <script src="{{ asset('dashboard/assets/plugins/jstree/jstree.wholerow.js') }}"></script>
    <script src="{{ asset('dashboard/assets/plugins/jstree/jstree.checkbox.js') }}"></script>

    <script !src="">
        $(function () {

            $('#jstree').jstree({
                "core": {
                    'data': {!! load_cat() !!},
                    "themes": {
                        "variant": "large"
                    }
                },
                "checkbox": {
                    "keep_selected_style": false
                },
                "plugins": ["wholerow"]
            });

            $('#jstree').on('changed.jstree', function (e, data) {

                var i, j, r = [];

                for (i = 0, j = data.selected.length; i < j; i++) {
                    r.push(data.instance.get_node(data.selected[i]).id);
                }

                $('.cat_id').val(r.join(', '));

                if (r.join(', ') != 0) {
                    $('.show_btn').attr('hidden', false);
                    var url = '{{ route('dashboard.categories.edit', ':id') }}';
                    url = url.replace(':id', r.join(', '));
                    $('.edit_cat').attr('href', url);

                    //delete
                    $('.delete_cat').on('click', function (e) {

                        var that = $(this);

                        e.preventDefault();

                        var n = new Noty({
                            text: "@lang('site.confirm_delete')",
                            type: "warning",
                            killer: true,
                            buttons: [
                                Noty.button("@lang('site.yes')", 'btn btn-success mr-2', function () {
                                    var del_url = '{{ route('dashboard.categories.destroy', ':id') }}';
                                    del_url = del_url.replace(':id', r.join(','));
                                    $('.form-del').attr('action', del_url);
                                    that.closest('form').submit();
                                }),

                                Noty.button("@lang('site.no')", 'btn btn-primary mr-2', function () {
                                    n.close();
                                })
                            ]
                        });

                        n.show();

                    });//end of delete

                } else {
                    $('.show_btn').attr('hidden', true);
                }

            })
        })
    </script>
@endsection
