@extends('layouts.dashboard.app')

@section('title', __('site.edit') . ' ' . __('site.category'))

@section('css')
    <link rel="stylesheet" href="{{ asset('dashboard/assets/plugins/jstree/themes/default/style.css') }}">
    <link rel="stylesheet" href="{{ asset('dashboard/assets/plugins/dropify/dist/css/dropify.min.css') }}">

    {{-- select 2 --}}
    <link rel="stylesheet" href="{{ asset('dashboard/assets/plugins/select2/dist/css/select2.min.css') }}">
@endsection

@section('breadcrumb')

    @include('layouts.dashboard._breadcrumb', [
            'title'=> trans('site.categories'),
            'breadcrumb'=>[trans('site.dashboard') => route('dashboard.index'), trans('site.categories') => route('dashboard.categories.index'), trans('site.edit') => '']
        ])

@endsection

@section('content')

    @include('partials._errors')

    <form action="{{ route('dashboard.categories.update', $category) }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        {{ method_field('put') }}
        <div class="card">

            <div class="card-body">
                <h3 class="card-title mb-4">@lang('site.edit')
                </h3>
                <div class="row">
                    <div class="col-md-7">

                        @foreach(config('translatable.locales') as  $locale)

                            <div class="form-group">
                                {!! Form::label($locale . '[category_name]',trans('site.' . $locale . '.category_name')) !!}
                                {!! Form::text($locale . '[category_name]', $category->translate($locale)->category_name,['class'=>'form-control', 'required' => false]) !!}
                            </div>

                            <div class="form-group">
                                {!! Form::label($locale . '[category_description]',trans('site.' . $locale . '.category_description')) !!}
                                {!! Form::textarea($locale . '[category_description]',$category->translate($locale)->category_description,['class'=>'form-control ckeditor', 'required' => true]) !!}
                            </div>

                        @endforeach

                        <div class="clearfix"></div>

                        <div id="jstree"></div>

                        <div class="clearfix mb-4"></div>

                        <input type="hidden" name="parent_id" class="parent_id">
                        
                        <div class="form-group">
                            {!! Form::label('main',trans('site.main')) !!}
                            {!! Form::select('main',['yes'=>trans('site.yes'),'no'=>trans('site.no')], $category->main,
                                ['class'=>'select2 form-control', 'style' => 'height: 42px;', 'placeholder' => trans('site.text_select')]) !!}
                        </div>
                        
                        <div class="form-group">
                            {!! Form::label('special',trans('site.special')) !!}
                            {!! Form::select('special',['yes'=>trans('site.yes'), 'no'=>trans('site.no')], $category->special,
                                ['class'=>'select2 form-control', 'style' => 'height: 42px;', 'placeholder' => trans('site.text_select')]) !!}
                        </div>

                        <div class="form-group">
                            {!! Form::label('slider',trans('site.slider')) !!}
                            {!! Form::select('slider',['yes'=>trans('site.yes'), 'no'=>trans('site.no')], $category->slider,
                                ['class'=>'select2 form-control', 'style' => 'height: 42px;', 'placeholder' => trans('site.text_select')]) !!}
                        </div>


                        <div class="form-group">
                            {!! Form::label('in_header',trans('site.in_header')) !!}
                            {!! Form::select('in_header',['yes'=>trans('site.yes'), 'no'=>trans('site.no')], $category->in_header,
                                ['class'=>'select2 form-control', 'style' => 'height: 42px;', 'placeholder' => trans('site.text_select')]) !!}
                        </div>

                        <div class="form-group mt-3">
                            {!! Form::label('keywords', trans('site.keywords')) !!}
                            {!! Form::textarea('keywords', $category->keywords , ['class'=>'form-control', 'rows' => '3']) !!}
                        </div>

                    </div>
                    <div class="col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">{{__('site.category_icon')}}</h4>

                                <input type="file" id="input-file-now-custom-1" class="dropify"
                                       name="icon"
                                       data-height="300"
                                       data-default-file="{{ $category->icon_path }}"/>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-info"><i class="fa fa-edit"></i> @lang('site.edit')
                    </button>
                </div>
            </div>

{{-- in_header --}}       </div>


    </form>

@endsection


@section('js')
    <script src="{{ asset('dashboard/assets/plugins/jstree/jstree.js') }}"></script>
    <script src="{{ asset('dashboard/assets/plugins/jstree/jstree.wholerow.js') }}"></script>
    <script src="{{ asset('dashboard/assets/plugins/jstree/jstree.checkbox.js') }}"></script>

    {{--Ckeditor--}}
    <script src="{{ asset('dashboard/assets/plugins/ckeditor/ckeditor.js') }}"></script>

    <script src="{{ asset('dashboard/assets/plugins/dropify/dist/js/dropify.min.js') }}"></script>

    {{-- select 2 --}}
    <script src="{{ asset('dashboard/assets/plugins/select2/dist/js/select2.min.js') }}"></script>

    <script !src="">
        $(function () {

            // CKeditor Language
            CKEDITOR.config.language = "{{app()->getLocale()}}";

            // Basic
            $('.dropify').dropify();

            // select 2
            $('.select2').select2();

            $('#jstree').jstree({
                "core": {
                    'data': {!! load_cat($category->parent_id, $category->id) !!},
                    "themes": {
                        "variant": "large"
                    }
                },
                "checkbox": {
                    "keep_selected_style": false
                },
                "plugins": ["wholerow"]
            });

            $('#jstree').on('changed.jstree', function (e, data) {

                var i, j, r = [];

                for (i = 0, j = data.selected.length; i < j; i++) {
                    r.push(data.instance.get_node(data.selected[i]).id);
                }

                $('.parent_id').val(r.join(', '));

            })

        })
    </script>
@endsection

