<?php
/**
 * Created by PhpStorm.
 * User: Samir
 * Date: 24/01/2019
 * Time: 15:34
 */

?>

<!-- ============================================================== -->
<!-- Topbar header - style you can find in pages.scss -->
<!-- ============================================================== -->
<header class="topbar">
    <nav class="navbar top-navbar navbar-expand-md navbar-light">
        <!-- ============================================================== -->
        <!-- Logo -->
        <!-- ============================================================== -->
        <div class="navbar-header">
            <a class="navbar-brand" target="_blank" href="">
                <!-- Logo icon --><b>
                    <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                    <!-- Dark Logo icon -->
                    <img src="{{asset('/dashboard/assets/images/logo-icon.png')}}" alt="homepage" class="dark-logo"/>
                    <!-- Light Logo icon -->
                    <img src="{{asset('/dashboard/assets/images/logo-light-icon.png')}}" alt="homepage"
                         class="light-logo"/>
                </b>
                <!--End Logo icon -->
                <!-- Logo text --><span>
                         <!-- dark Logo text -->
                         <img src="{{asset('/dashboard/assets/images/logo-text.png')}}" alt="homepage"
                              class="dark-logo"/>
                    <!-- Light Logo text -->
                         <img src="{{asset('/dashboard/assets/images/logo-light-text.png')}}" class="light-logo"
                              alt="homepage"/></span> </a>
        </div>
        <!-- ============================================================== -->
        <!-- End Logo -->
        <!-- ============================================================== -->
        <div class="navbar-collapse">
            <!-- ============================================================== -->
            <!-- toggle and nav items -->
            <!-- ============================================================== -->
            <ul class="navbar-nav mr-auto mt-md-0">
                <!-- This is  -->
                <li class="nav-item"><a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark"
                                        href="javascript:void(0)"><i class="mdi mdi-menu"></i></a></li>
                <li class="nav-item m-l-10"><a
                            class="nav-link sidebartoggler hidden-sm-down text-muted waves-effect waves-dark"
                            href="javascript:void(0)"><i class="ti-menu"></i></a></li>
                <!-- ============================================================== -->
                <!-- Comment -->
                <!-- ============================================================== -->
            </ul>
            <!-- ============================================================== -->
            <!-- User profile and search -->
            <!-- ============================================================== -->
            <ul class="navbar-nav my-lg-0">
                <!-- ============================================================== -->
                <!-- Language -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Profile -->
                <!-- ============================================================== -->
                <li class="nav-item dropdown">
                    <a  class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href=""
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                src="{{ admin()->user()->image_path }}" alt="user"
                                class="profile-pic"/></a>
                    <div style="right: auto;left: 0;" class="dropdown-menu {{app()->getLocale() == 'ar' ? '' : 'dropdown-menu-right'}} scale-up">
                        <ul class="dropdown-user">
                            <li>
                                <div class="dw-user-box">
                                    <div class="u-img"><img
                                                src="{{ admin()->user()->image_path }}"
                                                alt="user"></div>
                                    <div class="u-text">
                                        <h4>{{admin()->user()->name}}</h4>
                                        <p class="text-muted">{{admin()->user()->mobile}}</p>
                                        <a href=""
                                           class="btn btn-rounded btn-danger btn-sm">@lang('الحساب للشخصي')</a>
                                    </div>
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li><a href=""><i
                                            class="fa fa-power-off"></i> @lang('تسجيل خروج')</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header>
<!-- ============================================================== -->
<!-- End Topbar header -->
<!-- ============================================================== -->
