<?php
/**
 * Created by PhpStorm.
 * User: Samir
 * Date: 24/01/2019
 * Time: 15:36
 */
?>

<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- User profile -->
        <div class="user-profile">
            <!-- User profile image -->
            <div class="profile-img"><img src="{{ admin()->user()->image_path }}" alt="user"/>
                <!-- this is blinking heartbit-->
                <div class="notify setpos"><span class="heartbit"></span> <span class="point"></span></div>
            </div>
            <!-- User profile text-->
            <div class="profile-text">
                <h5>{{admin()->user()->name}}</h5>


                <a href="{{route('dashboard.logout')}}" class="" data-toggle="tooltip" title="@lang('site.logout')"><i
                            class="mdi mdi-power"></i></a>
            </div>
        </div>
        <!-- End User profile text-->
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li>
                    <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i
                                class="mdi mdi-gauge"></i><span
                                class="hide-menu">@lang('الرئيسيه')</span></a>

                    <ul aria-expanded="false" class="collapse">
                        <li><a href="{{ route('dashboard.index') }}"><i
                                        class="mdi mdi-gauge"></i> @lang('الرئيسيه') </a></li>

                    </ul>
                </li>





                <li>
                    <a class="waves-effect waves-dark" href="{{ route('dashboard.clients.index') }}" aria-expanded="false"><i
                            class="mdi mdi-account-convert"></i><span
                            class="hide-menu">@lang('العملاء')</span></a>
                </li>

                <li>
                    <a class="waves-effect waves-dark" href="{{ route('dashboard.clients.indexRequest') }}" aria-expanded="false"><i
                            class="mdi mdi-alert-circle"></i><span
                            class="hide-menu">@lang('الطلبات')</span></a>
                </li>



                    <li>
                        <a class="has-arrow waves-effect waves-dark"  aria-expanded="false"><i
                                    class="mdi mdi-widgets"></i><span
                                    class="hide-menu">@lang('الأقسام')</span></a>

                        <ul aria-expanded="false" class="collapse">
                            <li><a href="{{ route('dashboard.categories.index') }}"><i
                                            class="mdi mdi-widgets"></i> @lang('الأقسام') </a></li>
                            <li><a href="{{ route('dashboard.categories.create') }}"><i
                                            class="mdi mdi-plus-circle"></i> @lang('إضافة قسم') </a></li>
                        </ul>
                    </li>


                @if (admin()->user()->can('manage products'))
                    <li>
                        <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i
                                    class="mdi mdi-shopping"></i><span
                                    class="hide-menu">@lang('site.products')</span></a>

                        <ul aria-expanded="false" class="collapse">
                            <li><a href="{{ route('dashboard.products.index') }}"><i
                                            class="mdi mdi-shopping"></i> @lang('site.products') </a></li>
                            <li><a href="{{ route('dashboard.products.create') }}"><i
                                            class="mdi mdi-plus-circle"></i> @lang('site.add_product') </a></li>
                        </ul>
                    </li>
                @endif

                @if (admin()->user()->can('manage countries'))
                    <li>
                        <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i
                                    class="mdi mdi-flag"></i><span
                                    class="hide-menu">@lang('site.countries')</span></a>

                        <ul aria-expanded="false" class="collapse">
                            <li><a href="{{ route('dashboard.countries.index') }}"><i
                                            class="mdi mdi-flag"></i> @lang('site.countries') </a></li>
                            <li><a href="{{ route('dashboard.countries.create') }}"><i
                                            class="mdi mdi-plus-circle"></i> @lang('site.add_country') </a></li>
                        </ul>
                    </li>
                @endif


                @if (admin()->user()->can('manage cities'))
                    <li>
                        <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i
                                    class="mdi mdi-earth-box"></i><span
                                    class="hide-menu">@lang('site.cities')</span></a>

                        <ul aria-expanded="false" class="collapse">
                            <li><a href="{{ route('dashboard.cities.index') }}"><i
                                            class="mdi mdi-earth-box"></i> @lang('site.cities') </a></li>
                            <li><a href="{{ route('dashboard.cities.create') }}"><i
                                            class="mdi mdi-plus-circle"></i> @lang('site.add_city') </a></li>
                        </ul>
                    </li>
                @endif


            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
